from django.core.files.storage import FileSystemStorage
import assemblyai as aai

fs = FileSystemStorage()

aai.settings.api_key = "785d286df3f544e295edbf7fcfe25274"
config = aai.TranscriptionConfig(language_code="zh")
transcriber = aai.Transcriber(config=config)


def trans(name, wav):
    filename = fs.save(name, wav)
    file_path = fs.path(filename)
    transcript = transcriber.transcribe(file_path)
    return transcript