from other.module import os_setenv, get_zhipu, get_qianfan,get_wenxin
from langchain.memory import ConversationBufferMemory
from langchain_community.agent_toolkits.load_tools import load_tools
from langchain.agents import initialize_agent

os_setenv()


def agent(input_, model_id):
    if model_id == '1':
        chat_model = get_zhipu()
    elif model_id == '2':
        chat_model = get_qianfan()
    elif model_id == '3':
        chat_model = get_wenxin()
    tools = load_tools(tool_names=["serpapi"], llm=chat_model)
    memory = ConversationBufferMemory(memory_key="chat_history")
    conversational_agent = initialize_agent(
        agent='conversational-react-description',
        tools=tools,
        llm=chat_model,
        verbose=True,
        max_iterations=3,
        memory=memory,
        handle_parsing_errors=True,
    )
    response = conversational_agent.invoke(input_)
    return response["output"]
