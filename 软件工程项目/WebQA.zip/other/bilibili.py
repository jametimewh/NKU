from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough

from other.module import os_setenv,get_zhipu
os_setenv()
chat_model=get_zhipu()
SESSDATA = ('00187772%2C1744821841%2C1eabc%2Aa1CjBX69xDGDyQ-0Y6HOMr96XLZtWApySU8f4VN-wolGWmuQUO2DPcwQhJjD_kHQab0BkSVkVCejRDRHBQVDgzXzFWVTNpZXZTVFFjYkZRNm1udzNLYkVKelk0eUpMaVdpb0ZvZHNaNGJsOGpLbnR5cVFRMUk5aWgwZ0NXZWF0dmlHckt3OGZyNXNnIIEC')
BUVID3 = "AAC2E2F8-68B6-D2FE-ABCC-7F8188588D4029532infoc"
BILI_JCT = "d01efd2974ffcf1fdafd96c88c081670"
from langchain_community.document_loaders import BiliBiliLoader

from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter, CharacterTextSplitter  # 切分数据

from langchain.chains import create_history_aware_retriever
from langchain_core.prompts import MessagesPlaceholder, ChatPromptTemplate

template = """仅根据以下关于某视频的字幕信息回答问题:

    {context}

    Question: {question}
    """
prompt = ChatPromptTemplate.from_template(template)

EMBEDDING_DEVICE = 'cpu'
embeddings = HuggingFaceEmbeddings(model_name="C:/Users/86139/Desktop/项目/m3e-base",
                                   model_kwargs={'device': EMBEDDING_DEVICE})

text_splitter = RecursiveCharacterTextSplitter()
def fetch_bili(input_):
    loader = BiliBiliLoader(
        [
            input_,
        ],
        sessdata=SESSDATA,
        bili_jct=BILI_JCT,
        buvid3=BUVID3,
    )
    docs = loader.load()
    documents = text_splitter.split_documents(documents=docs)
    vector = FAISS.from_documents(documents=documents, embedding=embeddings)
    retriever = vector.as_retriever()
    chain = (
            {"context": retriever, "question": RunnablePassthrough()}
            | prompt
            | chat_model
            | StrOutputParser()
    )
    resp = chain.invoke("该视频的字幕的主要内容")
    return resp