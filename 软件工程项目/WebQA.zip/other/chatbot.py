from typing import Any, Dict, List
from langchain.chains.conversation.base import ConversationChain
from langchain.chains.llm import LLMChain
from langchain.chains.router import MultiPromptChain
from langchain.chains.router.llm_router import RouterOutputParser, LLMRouterChain
from langchain.chains.router.multi_prompt_prompt import MULTI_PROMPT_ROUTER_TEMPLATE as RouterTemplate
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
from langchain_core.prompts import MessagesPlaceholder, ChatPromptTemplate

from other.module import os_setenv, get_zhipu,get_qianfan,get_wenxin
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

os_setenv()

lawyer_template_str: str = """你是一个法律顾问，你需要根据用户提出的问题给出专业的法律意见，如果你不知道，请说"我不知道"，请不要提供超出文本范围外的内容，也不要自创内容。
用户提问：
{input}
"""
sales_template_str: str = """你是一个销售顾问，你需要为用户输入的商品进行介绍，你需要提供商品基本信息，以及其使用方式和保修条款。
用户输入的商品：
{input}
"""
english_teacher_template_str: str = """你是一个英语老师，用户输入的中文词汇，你需要提供对应的英文单词，包括单词词性，对应的词组和造句。
用户输入的中文词汇：
{input}
"""

poet_template_str = """ 你是一个诗人，你需要根据用户输入的主题作诗。
用户输入的主题:
{input}
"""

prompt_infos: List[Dict[str, Any]] = [
    {
        "key": "lawyer",
        "description": "咨询法律相关问题时很专业",
        "template": lawyer_template_str,
    },
    {
        "key": "sales",
        "description": "咨询商品信息时很专业",
        "template": sales_template_str,
    },
    {
        "key": "english teacher",
        "description": "能够很好地解答英语问题",
        "template": english_teacher_template_str,
    },
    {
        "key": "poet",
        "description": "作诗很专业",
        "template": poet_template_str,
    },
]
def chat(input_,model_id):
    if model_id == '1':
        chat_model = get_zhipu()
    elif model_id == '2':
        chat_model = get_qianfan()
    elif model_id == '3':
        chat_model = get_wenxin()
    chain_map: Dict[str, Any] = {}
    for info in prompt_infos:
        prompt: PromptTemplate = PromptTemplate(
            template=info["template"],
            input_variables=["input"],
        )
        chain: LLMChain = LLMChain( 
            prompt=prompt,
            llm=chat_model,
            verbose=True,
        )
        chain_map[info["key"]] = chain
    destinations: List[str] = [f"{p['key']}: {p['description']}" for p in prompt_infos]
    router_template: RouterTemplate = RouterTemplate.format(
        destinations="\n".join(destinations)
    )

    router_prompt: PromptTemplate = PromptTemplate(
        template=router_template,
        input_variables=["input"],
        output_parser=RouterOutputParser(),
    )
    router_chain: LLMRouterChain = LLMRouterChain.from_llm(
        llm=chat_model,
        prompt=router_prompt,
        verbose=True,
    )

    default_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "你是一个活泼的女助手，喜欢用可爱的语气回答问题，请不要使用emoji"),
            MessagesPlaceholder(variable_name='history'),
            ("human", "请告诉我，{input}"),
        ]
    )

    memory = ConversationBufferMemory(memory_key="history", return_messages=True, output_key="text")
    chain = LLMChain(llm=chat_model, prompt=default_prompt, memory=memory)

    chain: MultiPromptChain = MultiPromptChain(
        router_chain=router_chain,
        destination_chains=chain_map,
        default_chain=chain,
        verbose=True,
        memory=memory,
    )
    response = chain.invoke(input={"input": input_})
    return response["text"]
