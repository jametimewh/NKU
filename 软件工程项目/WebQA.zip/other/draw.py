from langchain_community.llms.replicate import Replicate
from other.module import os_setenv, get_zhipu

os_setenv()
chat_model = get_zhipu()
text2image = Replicate(
    model="stability-ai/stable-diffusion:db21e45d3f7023abc2a46ee38a23973f6dce16bb082a930b0c49861f96d1e5bf",
    model_kwargs={'image_dimensions': '512x512'})

from zhipuai import ZhipuAI
import requests

client = ZhipuAI(api_key="49d2550e025b5b93205c9d60f30a33e0.YtgbaJj7fABKMiVm")  # 请填写您自己的APIKey
history = []


def draw(input_, model_id):
    global history
    u = '请根据以下用户按顺序发送的关于AI绘画文生图的提示词模板历史记录:\n'
    t = 0
    for i in history:
        t += 1
        u += str(t) + ':' + i + '\n'
    u += '\n'
    u += '以上为历史提示词模板\n'
    u += "以及新发送的提示词:"
    u += input_ + '\n'
    u += '生成一个新的更适合的提示词,输出只需要包含更改后的提示词'
    prompt = chat_model.invoke(input=u)
    print(prompt)
    history.append(input_)
    if model_id == '1':
        response = client.images.generations(
            model="cogview-3",  # 填写需要调用的模型编码
            prompt=prompt.content,
        )
        response = response.data[0].url
    else:
        response = text2image(input_)
    print(history)
    return response
