from langchain.chains.llm import LLMChain
from langchain.memory import ConversationBufferMemory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

from other.module import os_setenv
from other.module import get_zhipu, get_qianfan

os_setenv()


def prompt_talk(human_message, system_message, model_id):
    if model_id == 1:
        chat_model = get_zhipu()
    else:
        chat_model = get_qianfan()
    default_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system_message),
            MessagesPlaceholder(variable_name='history'),
            ("human", "{input}"),
        ]
    )

    memory = ConversationBufferMemory(memory_key="history", return_messages=True, output_key="text")
    chain = LLMChain(llm=chat_model, prompt=default_prompt, memory=memory)
    resp = chain.invoke(input={"input": human_message})
    return resp['text']
