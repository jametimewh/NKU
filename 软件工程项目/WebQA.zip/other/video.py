from zhipuai import ZhipuAI
import requests

client = ZhipuAI(api_key="49d2550e025b5b93205c9d60f30a33e0.YtgbaJj7fABKMiVm")  # 请填写您自己的APIKey


def video(input_, model_id):
    response1 = client.videos.generations(
        model="cogvideox",
        prompt=input_
    )
    id = response1.id
    k = 'PROCESSING'
    while (k != 'SUCCESS'):
        response = client.videos.retrieve_videos_result(
            id=id
        )
        k = response.task_status

    return response.video_result[0].url
