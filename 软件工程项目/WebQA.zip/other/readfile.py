import os
from django.core.files.storage import FileSystemStorage
from langchain.chains.retrieval import create_retrieval_chain
from langchain.retrievers import MultiQueryRetriever
from langchain_community.vectorstores import Qdrant
from other.module import os_setenv, get_zhipu, get_qianfan
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter, CharacterTextSplitter  # 切分数据
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader, TextLoader

os_setenv()

EMBEDDING_DEVICE = 'cpu'
embeddings = HuggingFaceEmbeddings(model_name="C:/Users/86139/Desktop/项目/m3e-base",
                                   model_kwargs={'device': EMBEDDING_DEVICE})

documents = []
def readfile(input_, model_id):
    print('start readfile')
    fs = FileSystemStorage()
    filename = fs.save(input_.name, input_)
    file_path = fs.path(filename)
    suffix = os.path.splitext(file_path)[1]
    if suffix == '.pdf':
        loader = PyPDFLoader(file_path)
        documents.extend(loader.load())
    elif suffix == '.docx':
        loader = Docx2txtLoader(file_path)
        documents.extend(loader.load())
    elif suffix == '.txt':
        loader = TextLoader(file_path)
        documents.extend(loader.load())
    print('end readfile')
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=200, chunk_overlap=10)
    split_documents = text_splitter.split_documents(documents)
    vectorstore = Qdrant.from_documents(documents=split_documents,  # 指定分块的文档
                                        embedding=embeddings,  # 指定 embedding 模型
                                        location=':memory:',  # 指定 in-memory 存储
                                        collection_name='my_documents')  # 指定 类似 数据库的名称
    # 创建 retrieval 模型
    if model_id == '1':
        chat_model = get_zhipu()
    else:
        chat_model = get_qianfan()
    from langchain.chains.combine_documents import create_stuff_documents_chain
    from langchain_core.prompts import MessagesPlaceholder, ChatPromptTemplate
    prompt = ChatPromptTemplate.from_messages([
        ("system", "Answer the user's questions based on the bellow context:\n\n{context}"),
        MessagesPlaceholder(variable_name="chat_history"),
        ("user", "{input}")
    ])
    document_chain = create_stuff_documents_chain(llm=chat_model, prompt=prompt)
    retriever = vectorstore.as_retriever()
    retriever_from_llm = MultiQueryRetriever.from_llm(llm=chat_model, retriever=retriever)
    qa_chain = create_retrieval_chain(retriever_from_llm, document_chain)

    resp = qa_chain.invoke({
        "chat_history": [],
        'input': "为我总结文档的内容"
    })
    fs.delete(filename)
    print('end readfile')
    return resp['answer']
