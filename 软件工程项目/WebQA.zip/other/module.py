import os

from langchain_community.chat_models import ChatZhipuAI, QianfanChatEndpoint
from langchain_community.chat_models import ChatSparkLLM
from langchain_wenxin import Wenxin


def os_setenv():
    # 项目环境变量设置

    os.environ['IFLYTEK_SPARK_APP_ID'] = 'f627750d'
    os.environ['IFLYTEK_SPARK_API_KEY'] = 'MTEzZWUxYmU0YTExNDBkNWRlMjc4NzBm'
    os.environ['IFLYTEK_SPARK_API_SECRET'] = '2493c457fa8a7b63d949af6ec438b287'
    os.environ["IFLYTEK_SPARK_llm_DOMAIN"] = "generalv3"
    os.environ["IFLYTEK_SPARK_API_URL"] = "wss://spark-api.xf-yun.com/v3.1/chat"
    os.environ['ZHIPUAI_API_KEY'] = "0aaaceb3fd9a3fdf7c3351bcb3d5577d.ulHGjHjXE5xJjuXb"
    os.environ['USER_AGENT'] = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                                "Chrome/126.0.0.0 Safari/537.36")
    os.environ['SERPAPI_API_KEY'] = "020e328731bd31fcb1ad4e12bb7ec87090689b2f9cd15ba65399d0ce8442acae"
    os.environ["REPLICATE_API_TOKEN"] = "r8_52Zz6UnBXZJ52Yl27HhNH3bhzjit26b4Qoo1B"


def get_zhipu():
    zhipuai_chat_model = ChatZhipuAI(model='glm-4')

    chat_model = zhipuai_chat_model
    return chat_model


def get_qianfan():
    chat_model = QianfanChatEndpoint(
        qianfan_ak='kGyoGnCT3dwn5i3L6x9STXoP',
        qianfan_sk='78pITGhtj0FAD71jDWE3g7F87XuzhoDg',
        verbose=True,
        streaming=True,
    )
    return chat_model


def get_wenxin():
    API_KEY = 'eNNsHTP2NZGnyc9EpjarTG09'
    SECRET_KEY = 'FqNywWPbGGQ9R3Eza9WT50GnxOienCw6'
    chat_model = Wenxin(
        temperature=0.9,
        model="ERNIE-Bot-turbo",
        baidu_api_key=API_KEY,
        baidu_secret_key=SECRET_KEY, verbose=True
    )
    return chat_model
