from django.db import models


# Create your models here.
class user_table(models.Model):
    name = models.CharField(max_length=120)
    pwd = models.CharField(max_length=120)


class chat(models.Model):
    name = models.CharField(max_length=120)
    msg = models.CharField(max_length=1200)
    type = models.CharField(max_length=120)
    bot_id = models.CharField(max_length=10,default='1')
