import json

from django.core.files.storage import FileSystemStorage
from django.core.serializers.json import DjangoJSONEncoder
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from mainpro import models
# Create your views here.
from other.audio_to_text import trans
from other.chatbot import chat as chatbot
from other.bilibili import fetch_bili
from other.agent import agent
from other.readfile import readfile
from other.draw import draw
from other.video import video
from other.prompt import prompt_talk as p_t
from zhipuai import ZhipuAI

client = ZhipuAI(api_key="49d2550e025b5b93205c9d60f30a33e0.YtgbaJj7fABKMiVm")  # 请填写您自己的APIKey


def index(request):
    if request.method == 'GET':
        return render(request, 'home.html')
    name = request.POST.get('name')
    pwd = request.POST.get('pwd')
    user_table = models.user_table
    if user_table.objects.filter(name=name).exists():
        if user_table.objects.filter(name=name).values()[0]['pwd'] == pwd:
            request.session['name'] = name  # ----------------
            return redirect('/chat/')
        else:
            return render(request, 'home.html', {'error': "密码错误"})
    else:
        return render(request, 'home.html', {'error': "账号不存在"})


def chat(request):
    if request.method == 'GET':
        if not request.session.get('name'):
            return render(request, 'home.html')
        id = request.GET.get('id')
        print(id)
        if id is None:
            id = '1'
        if id == '1':
            chat_table = models.chat
            name = request.session.get('name')
            msgs = chat_table.objects.filter(name=name, bot_id='1').values()
            return render(request, 'chat.html', {'name': name, 'msgs': msgs, 'id': id,
                                                 'pre_msg': '本项目由哈基米组制作，一个简介 、美观、易用的 WebQA 聊天界面框架'})
        elif id == '2':
            chat_table = models.chat
            name = request.session.get('name')
            msgs = chat_table.objects.filter(name=name, bot_id='2').values()
            return render(request, 'chat.html', {'name': name, 'msgs': msgs, 'id': id,
                                                 'pre_msg': 'B站视频省流总结,发送b站视频url获取来自AI的总结'})
        elif id == '3':
            chat_table = models.chat
            name = request.session.get('name')
            msgs = chat_table.objects.filter(name=name, bot_id='3').values()
            return render(request, 'chat.html',
                          {'name': name, 'msgs': msgs, 'id': id, 'pre_msg': '调用Google Serpapi解决问题'})
        elif id == '4':
            chat_table = models.chat
            name = request.session.get('name')
            msgs = chat_table.objects.filter(name=name, bot_id='4').values()
            return render(request, 'chat.html', {'name': name, 'msgs': msgs, 'id': id, 'pre_msg': '读取用户发送文件'})
        elif id == '5':
            chat_table = models.chat
            name = request.session.get('name')
            msgs = chat_table.objects.filter(name=name, bot_id='5').values()
            return render(request, 'chat.html',
                          {'name': name, 'msgs': msgs, 'id': id, 'pre_msg': '文生图,输入描述AI绘制图片'})
        elif id == '6':
            chat_table = models.chat
            name = request.session.get('name')
            msgs = chat_table.objects.filter(name=name, bot_id='6').values()
            return render(request, 'chat.html',
                          {'name': name, 'msgs': msgs, 'id': id, 'pre_msg': "输入用户提示词与系统提示词"})
        elif id == '7':
            chat_table = models.chat
            name = request.session.get('name')
            msgs = chat_table.objects.filter(name=name, bot_id='7').values()
            return render(request, 'chat.html',
                          {'name': name, 'msgs': msgs, 'id': id, 'pre_msg': "视频生成"})


def register(request):
    if request.method == 'GET':
        return render(request, 'register.html')
    username = request.POST.get('name')
    pwd = request.POST.get('pwd')
    user_table = models.user_table
    if not user_table.objects.filter(name=username).exists():
        user_table.objects.create(name=username, pwd=pwd)
        return redirect('/chat/')
    else:
        return render(request, 'register.html', {'error': '账户名已存在'})


@csrf_exempt
def onechat(request):
    if request.method == 'GET':
        return HttpResponse("error")
    chat_table = models.chat
    data = json.loads(request.body)
    name = data['name']
    input_ = data['message']
    id = data['bot_id']
    model_id = data['model_id']
    print(model_id, " ", type(model_id))
    resp = ''
    if id == 1:
        resp = chatbot(input_, model_id)
    elif id == 2:
        resp = fetch_bili(input_)
    elif id == 3:
        resp = agent(input_, model_id=model_id)
    elif id == 4:
        resp = readfile(input_, model_id)
    elif id == 5:
        resp = draw(input_, model_id)
        print(resp)
    elif id == 7:
        resp = video(input_, model_id)
    chat_table.objects.create(name=name, msg=input_, type='user', bot_id=id)
    chat_table.objects.create(name=name, msg=resp, type='AI', bot_id=id)
    msgs = {
        'type': 'AI',
        'msg': resp,
        'name': 'AI',
    }
    return JsonResponse(msgs)


@csrf_exempt
def file_chat(request):
    if request.method == 'GET':
        return HttpResponse("error")
    chat_table = models.chat
    input_ = request.FILES.get('file')
    if input_ is None:
        return HttpResponse("error")
    name = request.session.get('name')
    model_id = request.POST.get('model_id')
    bot_id = request.POST.get('bot_id')
    resp = readfile(input_, model_id)
    msgs = {
        'type': 'AI',
        'msg': resp,
        'name': 'AI',
    }
    chat_table.objects.create(name=name, msg=resp, type='AI', bot_id=bot_id)
    return JsonResponse(msgs)


def delete_history(request):
    id = request.GET.get('id')
    name = request.session.get('name')
    chat_table = models.chat
    chat_table.objects.filter(name=name, bot_id=id).delete()
    return redirect('/chat?id=' + id)


@csrf_exempt
def prompt_talk(request):
    if request.method == 'GET':
        return HttpResponse("error")
    chat_table = models.chat
    data = json.loads(request.body)
    name = data['name']
    model_id = data['model_id']
    bot_id = data['bot_id']
    human_message = data['HumanMessage']
    system_message = data['SystemMessage']
    h_msg = human_message
    resp = p_t(human_message, system_message, model_id)
    chat_table.objects.create(name=name, msg=h_msg, type='user', bot_id=bot_id)
    chat_table.objects.create(name=name, msg=resp, type='AI', bot_id=bot_id)

    msgs = {
        'type': 'AI',
        'msg': resp,
        'name': 'AI',
    }
    return JsonResponse(msgs)


@csrf_exempt
def audio2text(request):
    if request.method == 'GET':
        return HttpResponse("error")
    wav = request.FILES.get('file')

    name = 'wav.wav'
    transcript = trans(name, wav)
    msgs = {
        'text': transcript.text,
    }
    return JsonResponse(msgs)
