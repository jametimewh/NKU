#include <iostream>
#include <algorithm>
#include <vector>
#include <ctime>
#include <immintrin.h>
#include <windows.h>
#include <omp.h>

using namespace std;

const int ARR_NUM = 10000;
const int ARR_LEN = 10000;
const int THREAD_NUM = 4;
vector<int> arr[ARR_NUM];
long long head, tail, freq; // timers

void init(void) {
    srand(static_cast<unsigned>(time(NULL)));
    for (int i = 0; i < ARR_NUM; i++) {
        arr[i].resize(ARR_LEN);
        for (int j = 0; j < ARR_LEN; j++) {
            arr[i][j] = rand();
        }
    }
}

void arr_sort_openmp_1() {
    int task_size = 50;
    QueryPerformanceCounter((LARGE_INTEGER*)&head);  // 记录并行计算开始的时间

    #pragma omp parallel num_threads(THREAD_NUM)
    {
        int thread_id = omp_get_thread_num();
        
        while (true) {
            int task;
            
            // 分配任务编号并更新全局任务变量
            #pragma omp critical
            {
                static int next_task = 0;
                task = next_task;
                next_task += task_size;
            }
            
            if (task >= ARR_NUM) break;

            int end = min(task + task_size, ARR_NUM); // 确保不会越界
            for (int i = task; i < end; i++) {
                stable_sort(arr[i].begin(), arr[i].end());
            }
        }

        #pragma omp critical
        {
            QueryPerformanceCounter((LARGE_INTEGER*)&tail); // 记录每个线程的结束时间
            printf("Thread %d finished in %lf ms.\n", thread_id, (tail - head) * 1000.0 / freq);
        }
    }
}

void arr_sort_openmp_2() {
    long long task_size = 50;
    QueryPerformanceCounter((LARGE_INTEGER*)&head);  // 记录并行计算开始的时间

    #pragma omp parallel num_threads(THREAD_NUM)
    {
        // 使用 OpenMP 的静态调度
        #pragma omp for schedule(static, task_size)
        for (int i = 0; i < ARR_NUM; i++) {
            stable_sort(arr[i].begin(), arr[i].end());
        }

        #pragma omp critical
        {
            QueryPerformanceCounter((LARGE_INTEGER*)&tail); // 记录每个线程的结束时间
            printf("Thread %d finished in %lf ms.\n", omp_get_thread_num(), (tail - head) * 1000.0 / freq);
        }
    }
}

void arr_sort_openmp_3() {
    long long tail;
    QueryPerformanceCounter((LARGE_INTEGER*)&head);
    // 使用 OpenMP 动态调度
    #pragma omp parallel num_threads(THREAD_NUM)
    {
        // 任务分配: 使用 dynamic 调度
        #pragma omp for schedule(dynamic, 10) // 这里使用了动态调度，每次分配10个任务
        for (int i = 0; i < ARR_NUM; i++) {
            stable_sort(arr[i].begin(), arr[i].end());
        }

        // 输出执行时间
        #pragma omp critical
        {
            QueryPerformanceCounter((LARGE_INTEGER *)&tail);
            printf("Thread %d: %lfms.\n", omp_get_thread_num(), (tail - head) * 1000.0 / freq);
        }
    }
}

void arr_sort_openmp_4() {
    long long tail;
    QueryPerformanceCounter((LARGE_INTEGER*)&head);
    // 使用 OpenMP guided 调度
    #pragma omp parallel num_threads(THREAD_NUM)
    {
        // 任务分配: 使用 guided 调度
        #pragma omp for schedule(guided, 10) // 使用 guided 调度，每次分配10个任务
        for (int i = 0; i < ARR_NUM; i++) {
            stable_sort(arr[i].begin(), arr[i].end());
        }

        // 输出执行时间
        #pragma omp critical
        {
            QueryPerformanceCounter((LARGE_INTEGER *)&tail);
            printf("Thread %d: %lfms.\n", omp_get_thread_num(), (tail - head) * 1000.0 / freq);
        }
    }
}

int main(int argc, char* argv[]) {
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq); // 获取计时器频率
    init();

    // 使用 OpenMP 并行执行排序
    cout<<"dynamic self"<<endl;
    arr_sort_openmp_1();
    cout<<"static"<<endl;
    arr_sort_openmp_2();
    cout<<"dynamic"<<endl;
    arr_sort_openmp_3();
    cout<<"guided"<<endl;
    arr_sort_openmp_4();
    return 0;
}
