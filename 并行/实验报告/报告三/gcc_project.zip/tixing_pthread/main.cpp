#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <chrono>
#include <iostream>
#include <cstdint>  // 添加这个头文件

void* Trap(void* rank);
double f(double x) {
    return 2.548 * x + 1.05;
}

// 全局变量
double global_result = 0.0;
double a, b;
int n;
int thread_count;
pthread_mutex_t mutex;

int main(int argc, char* argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <number of threads>\n", argv[0]);
        exit(1);
    }

    thread_count = strtol(argv[1], NULL, 10);
    pthread_t* thread_handles = (pthread_t*)malloc(thread_count * sizeof(pthread_t));
    
    printf("Enter a, b, and n\n");
    scanf("%lf %lf %d", &a, &b, &n);

    // 初始化互斥锁
    pthread_mutex_init(&mutex, NULL);

    auto start = std::chrono::high_resolution_clock::now();

    // 创建线程
    for (intptr_t thread = 0; thread < thread_count; thread++) {
        pthread_create(&thread_handles[thread], NULL, Trap, (void*)thread);
    }

    // 等待所有线程完成
    for (intptr_t thread = 0; thread < thread_count; thread++) {
        pthread_join(thread_handles[thread], NULL);
    }

    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end - start;
    std::cout << "time: " << duration.count() << "s" << std::endl;
    printf("With n = %d trapezoids, our estimate\n", n);
    printf("of the integral from %f to %f = %.14e\n", a, b, global_result);

    // 销毁互斥锁
    pthread_mutex_destroy(&mutex);
    free(thread_handles);

    std::cin.get();
    return 0;
}

void* Trap(void* rank) {
    intptr_t my_rank = (intptr_t)rank;  // 使用 intptr_t 类型
    double h = (b - a) / n;
    int local_n = n / thread_count;
    double local_a = a + my_rank * local_n * h;
    double local_b = local_a + local_n * h;
    double my_result = (f(local_a) + f(local_b)) / 2.0;

    for (int i = 1; i <= local_n; i++) {
        double x = local_a + i * h;
        my_result += f(x);
    }
    my_result *= h;

    // 使用互斥锁保护对 global_result 的更新
    pthread_mutex_lock(&mutex);
    global_result += my_result;
    pthread_mutex_unlock(&mutex);

    return NULL;
}
