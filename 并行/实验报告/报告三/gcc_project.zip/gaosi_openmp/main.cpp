#include <iostream>
#include <iomanip>
#include <random>
#include <chrono>
#include <omp.h>

const int N1 = 500;
const int N2 = 1000;
const int N3 = 2000;
const int THREAD_COUNT = 4;

void generateMatrix(float** matrix, int size) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(1.0, 100.0);

    for (int i = 0; i < size; ++i)
        for (int j = 0; j < size; ++j)
            matrix[i][j] = dis(gen);
}

// OpenMP 版本的高斯消元
void gaussianEliminationOpenMP(float** matrix, int size) {
    #pragma omp parallel for
    for (int k = 0; k < size; ++k) {
        // 主元化
        float pivot = matrix[k][k];
        for (int j = k; j < size; ++j) {
            matrix[k][j] /= pivot;
        }

        #pragma omp parallel for
        for (int i = k + 1; i < size; ++i) {
            float factor = matrix[i][k];
            for (int j = k; j < size; ++j) {
                matrix[i][j] -= factor * matrix[k][j];
            }
        }
    }
}

// 回代过程
void backSubstitution(float** matrix, float* solution, int size) {
    for (int i = size - 1; i >= 0; --i) {
        solution[i] = matrix[i][size];
        for (int j = i + 1; j < size; ++j) {
            solution[i] -= matrix[i][j] * solution[j];
        }
        solution[i] /= matrix[i][i];
    }
}

int main() {
    int sizes[] = {N1, N2, N3};

    for (int size : sizes) {
        std::cout << "Matrix size: " << size << "x" << size << "\n";

        // 初始化矩阵
        float** matrix = new float*[size];
        for (int i = 0; i < size; ++i) {
            matrix[i] = new float[size + 1]; // 增加一列来存放结果
        }

        // 生成随机矩阵
        generateMatrix(matrix, size);

        // 使用 OpenMP 进行高斯消元
        auto start = std::chrono::high_resolution_clock::now();
        gaussianEliminationOpenMP(matrix, size);
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = end - start;
        std::cout << "Multithreaded Gaussian Elimination Time: " << elapsed.count() << " seconds\n";

        // 初始化解向量
        float* solution = new float[size];

        // 回代
        start = std::chrono::high_resolution_clock::now();
        backSubstitution(matrix, solution, size);
        end = std::chrono::high_resolution_clock::now();
        elapsed = end - start;
        std::cout << "Back Substitution Time: " << elapsed.count() << " seconds\n";

        // 释放矩阵内存
        for (int i = 0; i < size; ++i) {
            delete[] matrix[i];
        }
        delete[] matrix;
        delete[] solution;

        std::cout << "\n";
    }
    return 0;
}
